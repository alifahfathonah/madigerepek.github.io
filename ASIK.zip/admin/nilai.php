<html>
<head>
<title> import nilai </title>
</head>
<body>
<h3>Import Nilai dari File Excel</h3>
<div class="well">
<form method="post" enctype="multipart/form-data" action="index.php?page=import-nilai">
Pilih File Excel*: <br/><br/><input name="fileexcel" type="file"> <br/>
<input name="upload" type="submit" value="Import" class="btn btn-primary">
</form><br>
<p>
* file yang bisa di import adalah .xls (Excel 2003-2007).</p>
download contoh file excel <a href="import-nilai.xls">Download</a> <br>
*) Jangan lupa hapus header di file excel setelah mengedit / input data, kemudian disave dan diimport.
</div>
</body>
</html>