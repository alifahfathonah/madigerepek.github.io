<h3>Tentang aplikasi</h3>
<div class="well">
<p><strong>ASIK adalah aplikasi sistem informasi pengumuman kelulusan ujian nasional online</strong></p>
</div>