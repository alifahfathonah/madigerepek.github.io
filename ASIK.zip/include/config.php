<?php
####db configuration
$dbhost			= "localhost";
$dbuser			= "root";
$dbpass			= "";
$dbname			= "sik";
$dbtype			= "mysql";
?>